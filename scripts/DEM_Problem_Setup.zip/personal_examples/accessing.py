import pathlib

import compas
from compas_dem.models import BlockModel
from compas_dem.problem import LoadCase
from compas_dem.problem import Problem

FILE = pathlib.Path(__file__).parent / "dem_arch.json"
problem: Problem = compas.json_load(FILE)
model: BlockModel = compas.json_load(pathlib.Path(__file__).parent / "dem_arch_model.json")

load_cases = problem.loadcases
load_case_gravity: LoadCase = load_cases[0]
load_case_displacement: LoadCase = load_cases[1]
load_case_surface_load: LoadCase = load_cases[2]
load_case_point_load: LoadCase = load_cases[3]

print("----------------------------------------------------------------")
print("\n")

print(f"Problem: {problem.guid} – Model: {model.guid} – {len(problem.loadcases)} Load Cases")
print("\n")
print("----------------------------------------------------------------")
print("\n")

print("Load Cases:")
print(f"Load Case 1: {load_cases[0].name}")
print(f"Load Case 2: {load_cases[1].name}")
print(f"Load Case 3: {load_cases[2].name}")
print(f"Load Case 4: {load_cases[3].name}")

print("\n")
print("----------------------------------------------------------------")
print("\n")


print(f"Load Case 1 Gravity: {load_case_gravity.g}")
print(f"Load Case 2 Displacements: {load_case_displacement._displacements}")
print(f"Load Case 3 Surface Loads: {load_case_surface_load._surface_loads}")
print(f"Load Case 4 Point Loads: {load_case_point_load._point_loads}")

print("\n")
print("----------------------------------------------------------------")
print("\n")


contact_properties = problem.contact_properties
print("Contact Properties:")
print(f"Contact Model with Phi: {contact_properties.contact_model.phi}")
print(f"Contact Model with C: {contact_properties.contact_model.c}")
print(f"Joint Model: Kn = {contact_properties.joint_model.kn}, Kt = {contact_properties.joint_model.kt}")


from compas_dem.analysis.resolve import resolve_centroidal_displacements
from compas_dem.analysis.resolve import resolve_centroidal_loads


print("\n")
print("----------------------------------------------------------------")
print("\n")

print("Supports set in the problem")
print(f"Supports: {problem._supports}")

print("\n")
print("----------------------------------------------------------------")
print("\n")

print("Centroidal Loads for Load Case 3 (Surface Loads):")
print(resolve_centroidal_loads(problem, model, loadcase=load_case_surface_load))

# Returns a dictionary of centroidal displacements for each block in the model, based on the specified load case.
